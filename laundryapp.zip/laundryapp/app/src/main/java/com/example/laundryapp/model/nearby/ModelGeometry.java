package com.example.laundryapp.model.nearby;

import com.google.gson.annotations.SerializedName;

/**

 * Github : https://github.com/Benimuhammadsiddiq

 */

public class ModelGeometry {

    @SerializedName("location")
    private ModelLocation modelLocation;

    public ModelLocation getModelLocation() {
        return modelLocation;
    }

    public void setModelLocation(ModelLocation modelLocation) {
        this.modelLocation = modelLocation;
    }

}
